const test=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const sandbox={window:{}, URL,AbortController,setTimeout,clearTimeout};
vm.runInNewContext(fs.readFileSync(path.join(root,'dist/design.js'),'utf8'),sandbox);
const D=sandbox.window.DormDesigner;
const K=require('../dist/kit.js');
const C=require('../dist/combat.js');
const players=D.defaults.map((p,i)=>({...p,body:i,...K.forPlayer(p,i)}));
const step=(m,n)=>{for(let i=0;i<n;i++)m.step();return m.snapshot();};
const tap=(m,key,i=0)=>{m.input(i,key,true);m.input(i,key,false);};

test('Chinese numerical values compile to bounded executable skill',()=>{
 const s=D.compile('《踩点闪现》机制：突进，前摇半秒，冷却五秒，威力十六');
 assert.equal(s.name,'踩点闪现');assert.equal(s.kind,'dash');assert.equal(s.delay,.5);assert.equal(s.cooldown,5);assert.equal(s.power,16);
});
test('explicit mechanism beats contradictory story and clamps extreme values',()=>{
 const s=D.compile('《回春》机制：heal 前摇 -10 冷却 999 威力 999','篮球投篮闹钟');
 assert.equal(s.kind,'heal');assert.equal(s.delay,0);assert.equal(s.cooldown,9);assert.equal(s.power,24);
});
test('AI JSON accepts fenced payload and rejects unsupported mechanisms',()=>{
 const s=D.parseImport('这是方案：\n```json\n'+JSON.stringify({name:'泡面回血',kind:'heal',prompt:'回复体力',power:20})+'\n```');
 assert.equal(s.kind,'heal');assert.throws(()=>D.parseImport('{"name":"胜利","kind":"kill","prompt":"秒杀"}'));
});
test('AI text does not execute and malformed output preserves exception',()=>{
 assert.throws(()=>D.parseImport('alert(1)'));assert.throws(()=>D.parseImport('null'));assert.throws(()=>D.parseImport('[]'));
 const s=D.parseImport({name:'<script>',kind:'burst',prompt:'<img onerror=alert(1)>',look:{color:'javascript:alert(1)'}});
 assert.equal(s.look.color,'#45596f');
});
test('wire roster omits story and prompt, bounds numbers and rejects remote image URLs',()=>{
 const p={...players[0],story:'PRIVATE',skill:{...players[0].skill,prompt:'PRIVATE'}};
 const result=K.forWire(p,0);assert.ok(result);assert.ok(!JSON.stringify(result).includes('PRIVATE'));
 assert.equal(K.forWire({...p,look:{...p.look,face:'https://evil.invalid/photo.jpg'}},0),null);
});
test('training custom heal runs and both slots have independent cooldowns',()=>{
 const p={...players[0],skill:D.compile({name:'泡面',kind:'heal',prompt:'回复',power:18,delay:.5,cooldown:6})};
 const m=C.createMatch([p,players[1]],{mode:'training',seed:1});tap(m,'skill');
 let s=step(m,60);assert.equal(s.hud.hp[0],83);assert.ok(s.hud.cd[0]>4);assert.equal(s.hud.cd2[0],0);
 tap(m,'skill2');s=step(m,40);assert.ok(s.hud.cd2[0]>0);assert.ok(s.hud.hp[1]<100);
});
test('ultimate spends four energy and cannot be repeated without recharge',()=>{
 const m=C.createMatch(players,{mode:'training',seed:1});tap(m,'ultimate');let s=step(m,60);assert.equal(s.hud.energy[0],0);assert.ok(s.hud.hp[1]<100);
 const hp=s.hud.hp[1];tap(m,'ultimate');s=step(m,60);assert.equal(s.hud.hp[1],hp);
});
test('substitute only works after a hit and spends one energy',()=>{
 const m=C.createMatch(players,{mode:'training',seed:1});tap(m,'substitute');let s=step(m,3);assert.equal(s.hud.energy[0],4);
 tap(m,'drill');s=step(m,37);assert.equal(s.hud.canSub[0],true);tap(m,'substitute');s=step(m,2);
 assert.equal(s.hud.energy[0],3);assert.ok(s.hud.subCd[0]>11);assert.equal(s.fighters[0].invulnerable,true);
});
test('release stops held movement and independent input sources are retained',()=>{
 const m=C.createMatch(players,{mode:'training'});m.input(0,'left',true,'keyboard');m.input(0,'left',true,'touch');step(m,10);m.input(0,'left',false,'keyboard');
 const a=m.snapshot().fighters[0].x;const b=step(m,10).fighters[0].x;assert.ok(b<a);m.release(0);const c=m.snapshot().fighters[0].x;assert.equal(step(m,10).fighters[0].x,c);
});
test('same seed and inputs produce deterministic match snapshots',()=>{
 const a=C.createMatch(players,{mode:'cpu',seed:42}),b=C.createMatch(players,{mode:'cpu',seed:42});
 for(let i=0;i<2200;i++){if(i%80===0){tap(a,'skill');tap(b,'skill');}a.step();b.step();}
 assert.deepEqual(a.snapshot(),b.snapshot());
});
test('match times out and freezes result',()=>{
 const m=C.createMatch(players,{mode:'duo',seed:1});const s=step(m,3800);assert.equal(s.result.winner,null);assert.equal(s.hud.time,0);assert.deepEqual(step(m,10),s);
});
test('AI request uses HTTPS and does not redirect or store credentials',async()=>{
 await assert.rejects(D.generate({baseUrl:'http://example.com',model:'test',key:'fake-test'}));
 let call;sandbox.fetch=async(url,init)=>{call={url,init};return {ok:true,json:async()=>({choices:[{message:{content:JSON.stringify({name:'测试',kind:'dash',prompt:'突进',delay:.3,cooldown:5,power:16})}}]})};};
 await D.generate({name:'测试',baseUrl:'https://example.com/v1',model:'test',key:'fake-test'});
 assert.equal(call.init.redirect,'error');assert.equal(call.init.credentials,'omit');assert.equal(call.url,'https://example.com/v1/chat/completions');
});

test('description stage requires explicit JSON and never compiles it as a skill',()=>{
 assert.equal(D.parseDescription('```json\n{"description":"《拖鞋快递》向前扔拖鞋。"}\n```').description,'《拖鞋快递》向前扔拖鞋。');
 assert.throws(()=>D.parseDescription('{"prompt":"突进"}'));
 assert.throws(()=>D.parseGenerated('{"description":"突进"}'));
 assert.ok(D.makeDescriptionPrompt({name:'阿迟',story:'每天踩点'}).includes('每天踩点'));
});
test('executable AI stage rejects missing, out-of-range and unsupported parameters without fallback',()=>{
 const good={name:'拖鞋快递',prompt:'向前扔拖鞋',kind:'projectile',delay:.2,cooldown:4,power:14};
 assert.equal(D.parseGenerated(good).kind,'projectile');
 for(const bad of [{...good,power:999},{...good,kind:'summon'},{...good,delay:undefined},{...good,cooldown:'4'},{...good,power:14.5}]) assert.throws(()=>D.parseGenerated(bad));
});
test('description API and executable API use distinct prompts and validation',async()=>{
 let request;
 sandbox.fetch=async(url,init)=>{request=JSON.parse(init.body);return {ok:true,json:async()=>({choices:[{message:{content:'{"description":"《早八冲刺》向前突进。"}'}}]})};};
 const result=await D.generate({story:'总迟到',task:'description',baseUrl:'https://example.com/v1',model:'test',key:'fake-test'});
 assert.equal(result.description,'《早八冲刺》向前突进。');assert.ok(request.messages[0].content.includes('description'));
 await assert.rejects(D.generate({story:'总迟到',task:'skill',baseUrl:'https://example.com/v1',model:'test',key:'fake-test'}));
});

test('held substitute survives old tap buffer, triggers once, and requires release to rearm',()=>{
 const m=C.createMatch(players,{mode:'training',seed:1});
 m.input(0,'substitute',true,'touch');step(m,30);tap(m,'drill');let s=step(m,40);
 assert.equal(s.hud.energy[0],3);assert.ok(s.hud.subCd[0]>11);
 step(m,60);tap(m,'drill');s=step(m,40);
 assert.equal(s.hud.energy[0],3);assert.equal(s.hud.subCd[0],0);assert.equal(s.hud.canSub[0],true);
 m.input(0,'substitute',false,'touch');m.input(0,'substitute',true,'keyboard');s=step(m,1);
 assert.equal(s.hud.energy[0],2);assert.ok(s.hud.subCd[0]>11);
});
test('substitute explains energy and cooldown blocks without spending or teleporting',()=>{
 const m=C.createMatch(players,{mode:'training',seed:1});tap(m,'ultimate');step(m,60);
 tap(m,'substitute');assert.match(m.snapshot().hud.callout,/需要 1 点/);
 tap(m,'drill');step(m,37);tap(m,'substitute');step(m,2);
 tap(m,'substitute');const s=m.snapshot();assert.match(s.hud.callout,/替身冷却/);assert.equal(s.hud.energy[0],0);
});
test('releasing or losing focus cancels held substitute before the next hit',()=>{
 for(const release of [m=>m.input(0,'substitute',false,'key'),m=>m.release(0)]){
  const m=C.createMatch(players,{mode:'training',seed:1});m.input(0,'substitute',true,'key');step(m,30);release(m);
  tap(m,'drill');const s=step(m,40);assert.equal(s.hud.energy[0],4);assert.equal(s.hud.subCd[0],0);
 }
});

test('KO shows deterministic falling phase before result; damage, input and timer freeze',()=>{
 const p={...players[0],skill:D.compile({name:'终结投掷',kind:'projectile',prompt:'投掷',power:24,delay:0,cooldown:3})};
 const m=C.createMatch([p,players[1]],{mode:'duo',seed:1});let s;
 for(let i=0;i<2000;i++){if(i%190===0)tap(m,'skill');m.step();s=m.snapshot();if(s.hud.hp[1]===0)break;}
 assert.equal(s.hud.hp[1],0);assert.equal(s.result,null);assert.equal(s.hud.phase,'ko');assert.equal(s.hud.callout,'K.O.');
 assert.equal(s.fighters[1].action,'down');assert.equal(s.fighters[1].phase,0);
 const time=s.hud.time,hp=s.hud.hp[0],x=s.fighters[0].x;
 m.input(0,'left',true);tap(m,'ultimate');s=step(m,30);
 assert.equal(s.result,null);assert.ok(s.fighters[1].phase>.8);assert.equal(s.hud.time,time);assert.equal(s.hud.hp[0],hp);assert.equal(s.fighters[0].x,x);
 s=step(m,30);assert.equal(s.result,null);assert.equal(s.fighters[1].phase,1);
 s=step(m,32);assert.equal(s.result.reason,'KO');assert.equal(s.result.winner,0);assert.deepEqual(step(m,10),s);
});
