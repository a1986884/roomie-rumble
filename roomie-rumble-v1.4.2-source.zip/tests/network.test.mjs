/** Real HTTP regression tests. No browser or external dependency; Node 22.13+. */
import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { fileURLToPath } from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const player={name:'测试选手',story:'never transmit this private story',look:{face:''},skill:{name:'测试投掷',kind:'projectile',power:24,cooldown:3,delay:0}};
async function launch(script,args=[]){
 const child=spawn(process.execPath,[script,'--port','0',...args],{cwd:root,stdio:['ignore','pipe','pipe']});
 let output='',error='';child.stderr.on('data',b=>error+=b);
 const base=await new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>{child.kill();reject(Error('Startup timeout: '+output+error));},8000);
  child.stdout.on('data',b=>{output+=b;const hit=output.match(/http:\/\/(?:localhost|127\.0\.0\.1):(\d+)/);if(hit){clearTimeout(timer);resolve('http://127.0.0.1:'+hit[1]);}});
  child.once('exit',code=>{clearTimeout(timer);reject(Error('Startup exited '+code+': '+error));});
 });
 return {base,async stop(){if(child.exitCode===null){const end=once(child,'exit');child.kill();await end;}}};
}
async function post(base,route,data={},headers={}){
 const res=await fetch(base+route,{method:'POST',headers:{'Content-Type':'application/json',...headers},body:JSON.stringify(data)});
 return {status:res.status,data:await res.json()};
}
async function events(base,ticket){
 const controller=new AbortController(),messages=[];
 const res=await fetch(base+'/lan/events?'+new URLSearchParams(ticket),{signal:controller.signal});
 assert.equal(res.status,200);assert.match(res.headers.get('content-type'),/text\/event-stream/);
 let rest='';const reader=res.body.getReader();
 const pump=(async()=>{try{for(;;){const {done,value}=await reader.read();if(done)break;rest+=new TextDecoder().decode(value);let i;while((i=rest.indexOf('\n\n'))>=0){const block=rest.slice(0,i);rest=rest.slice(i+2);if(block.startsWith('data: '))messages.push(JSON.parse(block.slice(6)));}}}catch(e){if(e.name!=='AbortError')throw e;}})();
 return {messages,async wait(predicate,timeout=6000){const until=Date.now()+timeout;while(Date.now()<until){const found=messages.find(predicate);if(found)return found;await delay(20);}throw Error('SSE condition timed out; types: '+messages.map(m=>m.type).join(','));},async close(){controller.abort();await pump;}};
}

test('LAN HTTP: validation, authorization, synchronized frames and reconnect',async t=>{
 const service=await launch('server.cjs',['--no-open']);t.after(()=>service.stop());
 const {base}=service;
 await t.test('serves game; refuses cross-origin and malformed inputs',async()=>{
  assert.equal((await fetch(base+'/')).status,200);
  assert.equal((await fetch(base+'/server.cjs')).status,404);
  assert.equal((await post(base,'/lan/create',{player},{Origin:'https://example.invalid'})).status,403);
  assert.equal((await post(base,'/lan/create',{player:{}})).status,400);
 });
 const host=await post(base,'/lan/create',{player});assert.equal(host.status,200);assert.match(host.data.room,/^\d{6}$/);assert.equal(host.data.seat,0);
 const guest=await post(base,'/lan/join',{room:host.data.room,player});assert.equal(guest.status,200);assert.equal(guest.data.seat,1);
 await t.test('full rooms, invalid tickets and guest start are rejected',async()=>{
  assert.equal((await post(base,'/lan/join',{room:host.data.room,player})).status,409);
  assert.equal((await post(base,'/lan/check',{...host.data,token:'invalid'})).status,403);
  assert.equal((await post(base,'/lan/start',guest.data)).status,403);
  assert.equal((await post(base,'/lan/start',host.data)).status,409);
 });
 const a=await events(base,host.data),b=await events(base,guest.data);t.after(()=>a.close());t.after(()=>b.close());
 await t.test('lobby synchronizes only public fighter properties',async()=>{
  const lobby=await a.wait(m=>m.type==='lobby'&&m.connected.every(Boolean));
  assert.equal(lobby.players[0].story,undefined);assert.equal(lobby.players[0].skill.prompt,undefined);
  assert.equal(lobby.players[0].skill.power,24);
 });
 const start=await post(base,'/lan/start',host.data);assert.equal(start.status,200);const round=start.data.round;
 await t.test('start retry is idempotent and frames agree on both devices',async()=>{
  assert.equal((await post(base,'/lan/start',host.data)).data.round,round);
  await a.wait(m=>m.type==='frame'&&m.frame.hud.phase==='fight');
  const frame=await b.wait(m=>m.type==='frame'&&m.frame.hud.phase==='fight');
  const matching=await a.wait(m=>m.type==='frame'&&m.frame.elapsed===frame.frame.elapsed);
  assert.deepEqual(matching,frame);
 });
 await t.test('a skill changes shared HP; duplicate input sequence is harmless',async()=>{
  assert.equal((await post(base,'/lan/input',{...guest.data,round,seq:1,held:['substitute'],tap:['substitute']})).status,200);
  await delay(300); // Hold beyond the old 0.2-second input buffer.
  const input={...host.data,round,seq:1,held:[],tap:['skill']};
  assert.equal((await post(base,'/lan/input',input)).status,200);
  assert.equal((await post(base,'/lan/input',input)).status,200);
  const hit=await a.wait(m=>m.type==='frame'&&m.frame.hud.hp[1]<100);
  assert.equal(hit.frame.hud.hp[1],76);
  const same=await b.wait(m=>m.type==='frame'&&m.frame.elapsed===hit.frame.elapsed);
  assert.deepEqual(same.frame.hud,hit.frame.hud);
  const escaped=await b.wait(m=>m.type==='frame'&&m.frame.hud.subCd[1]>11);
  assert.equal(escaped.frame.hud.energy[1],1);
  const mirrored=await a.wait(m=>m.type==='frame'&&m.frame.elapsed===escaped.frame.elapsed);
  assert.deepEqual(mirrored.frame.hud,escaped.frame.hud);
  assert.equal((await post(base,'/lan/input',{...guest.data,round,seq:2,held:[],tap:[]})).status,200);
  assert.equal((await post(base,'/lan/input',{...input,seq:2,tap:['invalid']})).status,400);
 });
 await t.test('disconnect pauses; reconnect resumes the same round',async()=>{
  await b.close();await a.wait(m=>m.type==='status'&&m.paused);
  const resumed=await events(base,guest.data);b.messages=resumed.messages; b.wait=resumed.wait;t.after(()=>resumed.close());
  const initial=await resumed.wait(m=>m.type==='start');assert.equal(initial.round,round);
  await resumed.wait(m=>m.type==='status'&&!m.paused);
 });
 await t.test('LAN KO broadcasts a falling interval before the same result on both seats',async()=>{
  let latest=a.messages.filter(m=>m.type==='frame').at(-1);
  for(let seq=3;seq<8&&latest.frame.hud.hp[1]>0;seq++){
   const ready=await a.wait(m=>m.type==='frame'&&m.frame.elapsed>latest.frame.elapsed&&m.frame.hud.cd[0]===0);
   await post(base,'/lan/input',{...host.data,round,seq,held:[],tap:['skill']});
   latest=await a.wait(m=>m.type==='frame'&&m.frame.elapsed>ready.frame.elapsed&&m.frame.hud.hp[1]<ready.frame.hud.hp[1]);
  }
  assert.equal(latest.frame.hud.hp[1],0);assert.equal(latest.frame.result,null);assert.equal(latest.frame.hud.phase,'ko');
  const mirror=await b.wait(m=>m.type==='frame'&&m.frame.elapsed===latest.frame.elapsed);assert.deepEqual(mirror.frame,latest.frame);
  const final=await a.wait(m=>m.type==='frame'&&m.frame.result?.reason==='KO');
  assert.ok(final.frame.elapsed-latest.frame.elapsed>=1.4);assert.equal(final.frame.hud.time,latest.frame.hud.time);
  const other=await b.wait(m=>m.type==='frame'&&m.frame.elapsed===final.frame.elapsed);assert.deepEqual(other.frame.result,final.frame.result);
 });
 await t.test('guest leave frees seat; host leave closes room',async()=>{
  assert.equal((await post(base,'/lan/leave',guest.data)).status,200);
  assert.equal((await post(base,'/lan/check',guest.data)).status,403);
  assert.equal((await post(base,'/lan/join',{room:host.data.room,player})).status,200);
  assert.equal((await post(base,'/lan/leave',host.data)).status,200);
  assert.equal((await post(base,'/lan/check',host.data)).status,404);
 });
});

test('phone pairing HTTP: tickets, signaling, relay and closure',async t=>{
 const service=await launch('scripts/dev-pair.mjs');t.after(()=>service.stop());const {base}=service;
 const requestKey='a'.repeat(48),guestKey='b'.repeat(48);
 await t.test('availability and request guards',async()=>{
  assert.equal((await fetch(base+'/pair/info')).status,200);
  assert.equal((await post(base,'/pair/create',{}, {Origin:'https://example.invalid'})).status,403);
  assert.equal((await post(base,'/pair/create',{requestKey:'bad'})).status,400);
  assert.equal((await fetch(base+'/pair/create')).status,405);
 });
 const host=(await post(base,'/pair/create',{requestKey})).data;
 const guest=(await post(base,'/pair/join',{room:host.room,requestKey:guestKey})).data;
 await t.test('create/join retries preserve seat while a third player is rejected',async()=>{
  assert.match(host.room,/^\d{6}$/);assert.equal(host.seat,0);assert.equal(guest.seat,1);
  assert.deepEqual((await post(base,'/pair/create',{requestKey})).data,host);
  assert.deepEqual((await post(base,'/pair/join',{room:host.room,requestKey:guestKey})).data,guest);
  assert.equal((await post(base,'/pair/join',{room:host.room})).status,409);
  assert.equal((await post(base,'/pair/poll',{...host,token:'c'.repeat(48)})).status,403);
 });
 await t.test('signaling deduplicates messages and restricts peer visibility',async()=>{
  const msg={...host,id:'offer-1',message:{type:'offer',sdp:'synthetic test SDP'}};
  assert.equal((await post(base,'/pair/send',msg)).status,200);
  assert.equal((await post(base,'/pair/send',msg)).status,200);
  const poll=(await post(base,'/pair/poll',guest)).data;
  assert.equal(poll.messages.length,1);assert.equal(poll.messages[0].message.sdp,'synthetic test SDP');
  assert.equal((await post(base,'/pair/poll',host)).data.messages.length,0);
  assert.equal((await post(base,'/pair/poll',{...guest,after:poll.messages[0].id})).data.messages.length,0);
 });
 const hostInstance='host_instance',guestInstance='guest_instance';
 const h={...host,instance:hostInstance,peer:guestInstance},g={...guest,instance:guestInstance,peer:hostInstance};
 await t.test('relay exchanges reliable input and frame packets with acknowledgments',async()=>{
  assert.equal((await post(base,'/pair/relay',{...h,peer:''})).status,200);
  assert.equal((await post(base,'/pair/relay',g)).status,200);
  const send=await post(base,'/pair/relay',{...h,batch:{seq:1,packets:[{type:'input',held:['right']}]},frame:{seq:1,after:1,packet:{type:'frame',hp:[100,76]}}});
  assert.equal(send.status,200);assert.equal(send.data.accepted,1);
  const received=(await post(base,'/pair/relay',g)).data;
  assert.deepEqual(received.batch.packets,[{type:'input',held:['right']}]);assert.deepEqual(received.frame.packet.hp,[100,76]);
  assert.equal((await post(base,'/pair/relay',{...g,ack:1,afterFrame:1})).data.batch,null);
  const acked=(await post(base,'/pair/relay',h)).data;assert.equal(acked.acked,1);
 });
 await t.test('page takeover rejects the previous page and leave invalidates both tickets',async()=>{
  assert.equal((await post(base,'/pair/relay',{...g,instance:'guest_new_page'})).status,200);
  assert.equal((await post(base,'/pair/relay',g)).status,409);
  assert.equal((await post(base,'/pair/leave',guest)).status,200);
  assert.equal((await post(base,'/pair/poll',host)).status,404);
  assert.equal((await post(base,'/pair/poll',guest)).status,404);
 });
});
