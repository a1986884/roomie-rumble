CREATE TABLE `pair_relay` (
	`room` text NOT NULL,
	`seat` integer NOT NULL,
	`instance` text NOT NULL,
	`previous` text DEFAULT '' NOT NULL,
	`seen` integer NOT NULL,
	`away` integer DEFAULT 0 NOT NULL,
	`peer` text DEFAULT '' NOT NULL,
	`ack` integer DEFAULT 0 NOT NULL,
	`batch_seq` integer DEFAULT 0 NOT NULL,
	`packets` text,
	`frame_seq` integer DEFAULT 0 NOT NULL,
	`frame_after` integer DEFAULT 0 NOT NULL,
	`frame` text,
	FOREIGN KEY (`room`) REFERENCES `pair_rooms`(`room`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pair_relay_seat` ON `pair_relay` (`room`,`seat`);