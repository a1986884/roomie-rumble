CREATE TABLE `pair_messages` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`room` text NOT NULL,
	`sender` integer NOT NULL,
	`client_id` text NOT NULL,
	`message` text NOT NULL,
	FOREIGN KEY (`room`) REFERENCES `pair_rooms`(`room`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pair_messages_once` ON `pair_messages` (`room`,`sender`,`client_id`);--> statement-breakpoint
CREATE INDEX `pair_messages_cursor` ON `pair_messages` (`room`,`sender`,`id`);--> statement-breakpoint
CREATE TABLE `pair_rooms` (
	`room` text PRIMARY KEY NOT NULL,
	`host_key` text NOT NULL,
	`guest_key` text,
	`expires` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `pair_rooms_host_key_unique` ON `pair_rooms` (`host_key`);--> statement-breakpoint
CREATE INDEX `pair_rooms_expiry` ON `pair_rooms` (`expires`);