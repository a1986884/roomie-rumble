import { sqliteTable, text, integer, index, uniqueIndex } from 'drizzle-orm/sqlite-core';

export const rooms = sqliteTable('pair_rooms', {
  room: text('room').primaryKey(),
  hostKey: text('host_key').notNull().unique(),
  guestKey: text('guest_key'),
  expires: integer('expires').notNull()
}, table => [index('pair_rooms_expiry').on(table.expires)]);

export const messages = sqliteTable('pair_messages', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  room: text('room').notNull().references(() => rooms.room, { onDelete: 'cascade' }),
  sender: integer('sender').notNull(),
  clientId: text('client_id').notNull(),
  message: text('message').notNull()
}, table => [
  uniqueIndex('pair_messages_once').on(table.room, table.sender, table.clientId),
  index('pair_messages_cursor').on(table.room, table.sender, table.id)
]);

// Each seat replaces its last frame and retains just one acknowledged batch of ordered events.
export const relay = sqliteTable('pair_relay', {
  room: text('room').notNull().references(() => rooms.room, { onDelete: 'cascade' }),
  seat: integer('seat').notNull(),
  instance: text('instance').notNull(),
  previous: text('previous').notNull().default(''),
  seen: integer('seen').notNull(),
  away: integer('away').notNull().default(0),
  peer: text('peer').notNull().default(''),
  ack: integer('ack').notNull().default(0),
  batchSeq: integer('batch_seq').notNull().default(0),
  packets: text('packets'),
  frameSeq: integer('frame_seq').notNull().default(0),
  frameAfter: integer('frame_after').notNull().default(0),
  frame: text('frame')
}, table => [uniqueIndex('pair_relay_seat').on(table.room, table.seat)]);
