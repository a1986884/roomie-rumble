"""Build the downloadable host, phone-room source, and one-file offline game."""
import argparse
import base64
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
DOWNLOAD = ROOT / "dist" / "downloads" / "host.zip"
STANDALONE = "开始游戏.html"
SCRIPT = re.compile(r'<script\b([^>]*)>\s*</script>', re.I)
STYLESHEET = re.compile(r'<link\b[^>]*\brel=["\']stylesheet["\'][^>]*>', re.I)
FILE_ATTR = re.compile(r'''\b(?:src|href)=["']([^"']+)["']''', re.I)
CSS_URL = re.compile(r'''url\(\s*["']?([^\s'")]+)["']?\s*\)''', re.I)
IMAGE_TYPES = {".webp": "image/webp", ".png": "image/png", ".jpg": "image/jpeg",
               ".jpeg": "image/jpeg", ".gif": "image/gif", ".svg": "image/svg+xml"}


class OfflineLayout(HTMLParser):
    def __init__(self):
        super().__init__()
        self.scripts = []
        self.blocked = []
        self.inside_script = False

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        self.inside_script = tag == "script"
        if self.inside_script:
            self.scripts.append("")
        if tag in {"script", "link", "img", "source", "audio", "video"}:
            url = attrs.get("src") or attrs.get("href") or attrs.get("poster") or ""
            if url and not url.startswith("data:"):
                self.blocked.append(url)

    def handle_endtag(self, tag):
        if tag == "script":
            self.inside_script = False

    def handle_data(self, data):
        if self.inside_script:
            self.scripts[-1] += data


def snapshot(root):
    root_files = ["README.md", "server.cjs", "启动局域网.cmd", "package-release.py", "package.json"]
    files = {name: (root / name).read_bytes() for name in root_files}
    # A distributable build has no link to the owner’s hosted project.
    files[".openai/hosting.json"] = b'{"d1":"DB"}\n'
    for folder, types in [("worker", {".mjs"}), ("db", {".mjs"}), ("scripts", {".mjs"}), ("drizzle", {".sql", ".json"}), ("tests", {".cjs", ".mjs"}), ("docs", {".md", ".html", ".svg", ".json"})]:
        for source in sorted((root / folder).rglob("*")):
            if source.is_file() and not source.is_symlink() and source.suffix in types and "content-drafts" not in source.parts:
                files[source.relative_to(root).as_posix()] = source.read_bytes()
    for ext in [".cmd", ".bat", ".sh", ".command"]:
        for launcher in sorted(root.glob("*" + ext)):
            if not launcher.is_symlink():
                files[launcher.name] = launcher.read_bytes()
    dist = root / "dist"
    # Do not descend into release archives, dotfiles, or other working directories.
    for item in sorted(dist.iterdir()):
        if item.is_symlink() or item.name.startswith("."):
            continue
        if item.is_file() and item.suffix in {".js", ".css", ".html", ".json"}:
            files["dist/" + item.name] = item.read_bytes()
    for asset in sorted((dist / "assets").rglob("*")):
        if asset.is_file() and not asset.is_symlink() and asset.suffix.lower() in IMAGE_TYPES:
            files[asset.relative_to(root).as_posix()] = asset.read_bytes()
    return files


def filename(tag):
    match = FILE_ATTR.search(tag)
    if not match:
        raise ValueError("Missing external source in template for " + tag)
    return match[1]


def make_offline(files):
    template = files["dist/index.html"].decode()
    assets = {
        name.removeprefix("dist/assets/"): "data:" + IMAGE_TYPES[Path(name).suffix.lower()]
        + ";base64," + base64.b64encode(data).decode("ascii")
        for name, data in files.items() if name.startswith("dist/assets/")
    }
    ordered_names = []
    inline_scripts = []

    def collect_script(match):
        name = filename(match[0])
        code = files["dist/" + name].decode()
        if name == "art.js":
            replacement = ("  const offlineAssets = " + json.dumps(assets, separators=(",", ":"))
                           + ";\n  const assetURL = name => offlineAssets[name];")
            code, count = re.subn(r"(?m)^[ \t]*const assetURL = [^\n]+;",
                                  lambda _: replacement, code)
            if count != 1:
                raise ValueError("Expected one art asset resolver")
        if "</script" in code.lower():
            raise ValueError("Unsafe HTML script terminator in " + name)
        ordered_names.append(name)
        inline_scripts.append("\n" + code + "\n")
        return ""

    def embed_stylesheet(match):
        name = filename(match[0])
        css = files["dist/" + name].decode()

        def replace_asset(link):
            ref = link[1]
            if ref.startswith(("data:", "#")):
                return link[0]
            path = (Path(name).parent / ref).as_posix()
            if not path.startswith("assets/") or path[7:] not in assets:
                raise ValueError("Unembedded style resource in " + name + ": " + ref)
            return "url(" + assets[path[7:]] + ")"

        return "<style>" + CSS_URL.sub(replace_asset, css) + "</style>"

    html = STYLESHEET.sub(embed_stylesheet, SCRIPT.sub(collect_script, template))
    if len(set(ordered_names)) != len(ordered_names):
        raise ValueError("A script is loaded more than once")
    order = {name: pos for pos, name in enumerate(ordered_names)}
    for name in ["kit.js", "keys.js", "art.js", "design.js", "combat.js", "mobile.js", "lan.js"]:
        if name not in order or order[name] >= order["app.js"]:
            raise ValueError(name + " must load before app.js")
    if max(order["keys.js"], order["kit.js"]) >= order["combat.js"]:
        raise ValueError("keys.js must load before combat.js")
    if html.count("</body>") != 1:
        raise ValueError("Missing or duplicated HTML body")
    scripts = "".join("<script>" + body + "</script>\n" for body in inline_scripts)
    html = html.replace("</body>", scripts + "</body>")
    layout = OfflineLayout()
    layout.feed(html)
    if layout.scripts != inline_scripts or layout.blocked:
        raise ValueError("Standalone dependencies or script order mismatch: " + str(layout.blocked))
    for name, url in assets.items():
        if url not in html:
            raise ValueError("Missing embedded image: " + name)
    for body in inline_scripts:
        subprocess.run(["node", "--check", "-"], input=body.encode(), check=True)
    return html.encode()


def verify(path, expected):
    with ZipFile(path) as archive:
        names = archive.namelist()
        if archive.testzip() or sorted(names) != sorted(expected):
            raise ValueError("Archive has a damaged, duplicate, missing or extra entry")
        for name, content in expected.items():
            if archive.read(name) != content:
                raise ValueError("Archive source differs: " + name)


def build(path, expected):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as tmp:
        temp = Path(tmp.name)
    try:
        with ZipFile(temp, "w") as archive:
            for name in [STANDALONE] + sorted(n for n in expected if n != STANDALONE):
                entry = ZipInfo(name, (2020, 1, 1, 0, 0, 0))
                entry.create_system = 3
                executable = name.endswith((".sh", ".command"))
                entry.external_attr = (0o100755 if executable else 0o100644) << 16
                archive.writestr(entry, expected[name], compress_type=ZIP_DEFLATED, compresslevel=9)
        verify(temp, expected)
        temp.chmod(0o644)
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def copy_download(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    if source.resolve() == target.resolve():
        return
    with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as tmp:
        temp = Path(tmp.name)
    try:
        shutil.copyfile(source, temp)
        temp.chmod(0o644)
        if target.exists() and hasattr(os, "listxattr"):
            for key in os.listxattr(target):
                os.setxattr(temp, key, os.getxattr(target, key))
        temp.replace(target)
    finally:
        temp.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--copy", type=Path, help="also write or verify an identical distribution ZIP")
    args = parser.parse_args()
    files = snapshot(ROOT)
    files[STANDALONE] = make_offline(files)
    subprocess.run(["node", "--check", str(ROOT / "server.cjs")], check=True)
    if args.verify_only:
        verify(DOWNLOAD, files)
        if args.copy and args.copy.read_bytes() != DOWNLOAD.read_bytes():
            raise ValueError("Distribution copy differs from hosted download")
    else:
        build(DOWNLOAD, files)
        if args.copy:
            copy_download(DOWNLOAD, args.copy)
    print(f"{DOWNLOAD.name}: {len(files)} entries, {DOWNLOAD.stat().st_size} bytes")


if __name__ == "__main__":
    main()
