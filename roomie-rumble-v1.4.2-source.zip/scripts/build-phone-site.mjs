// Build a single Worker module with the same byte-for-byte game files as the LAN host.
import { mkdir, readdir, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { gzipSync } from 'node:zlib';
import { gameAssetKey } from '../worker/site.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const dist = resolve(root, 'dist');
const files = {};

async function addFiles(relativeDir) {
  const entries = await readdir(join(dist, relativeDir), { withFileTypes: true });
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name, 'en'))) {
    const key = relativeDir ? relativeDir + '/' + entry.name : entry.name;
    if (entry.isDirectory() && (key === 'downloads' || key === 'assets' || key.startsWith('assets/'))) {
      await addFiles(key);
    }
    if (!entry.isFile() || gameAssetKey('/' + key) !== key) continue;
    if (/(?:^|[-_/])(qa|test)(?:[.-]|$)/i.test(key)) throw new Error('Remove QA file from release: ' + key);
    const bytes = await readFile(join(dist, key));
    const digest = createHash('sha256').update(bytes).digest('hex').slice(0, 24);
    files[key] = [bytes.length, '"' + digest + '"', bytes.toString('base64')];
  }
}
await addFiles('');
for (const key of ['index.html', 'downloads/host.zip', 'assets/fighters.webp', 'assets/dorm.webp']) {
  if (!files[key]) throw new Error('Missing required game asset: ' + key);
}
const [pairSource, router, manifest] = await Promise.all([
  readFile(join(root, 'worker/pair.mjs'), 'utf8'), readFile(join(root, 'worker/site.mjs'), 'utf8'),
  readFile(join(root, '.openai/hosting.json'), 'utf8')
]);
const config = JSON.parse(manifest);
if (config.static || config.d1 !== 'DB') throw new Error('Phone room hosting requires D1 binding DB');
const source = [
  pairSource, router, 'const gameFiles = ' + JSON.stringify(files) + ';',
  `export default createGameSite(handlePair, key => {
    const file = gameFiles[key];
    if (!file) return null;
    return {
      length: file[0], etag: file[1],
      read() {
        const binary = atob(file[2]);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        return bytes;
      }
    };
  });`
].join('\n');
await Promise.all([mkdir(join(dist, 'server'), { recursive: true }), mkdir(join(dist, '.openai'), { recursive: true })]);
await Promise.all([
  writeFile(join(dist, 'server/index.js'), source),
  writeFile(join(dist, '.openai/hosting.json'), manifest)
]);
const module = await import('data:text/javascript;base64,' + Buffer.from(source).toString('base64'));
for (const key of Object.keys(files)) {
  const response = await module.default.fetch(new Request('https://game.invalid/' + key), {});
  const bytes = Buffer.from(await response.arrayBuffer());
  if (response.status !== 200 || !bytes.equals(await readFile(join(dist, key)))) {
    throw new Error('Served asset differs from source: ' + key);
  }
}
console.log('Phone Worker verified: ' + Object.keys(files).length + ' assets, ' + gzipSync(source).length + ' bytes gzip');
