// Local Worker preview. Requires Node 22.13+ for node:sqlite. Room data lives only in memory.
import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readdir, readFile, stat } from 'node:fs/promises';
import { Readable } from 'node:stream';
import { createGameSite } from '../worker/site.mjs';
import { handlePair } from '../worker/pair.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const db = new DatabaseSync(':memory:');
db.exec('PRAGMA foreign_keys=ON');
for (const name of (await readdir(join(root, 'drizzle'))).filter(n => n.endsWith('.sql')).sort()) {
  db.exec(await readFile(join(root, 'drizzle', name), 'utf8'));
}

class Statement {
  constructor(query, values = []) { this.query = query; this.values = values; }
  bind(...values) { return new Statement(this.query, values); }
  first(column) {
    const row = db.prepare(this.query).get(...this.values);
    return (column ? row?.[column] : row) ?? null;
  }
  run() {
    const s = db.prepare(this.query);
    const r = s.run(...this.values);
    return { success: true, results: [], meta: { changes: r.changes, last_row_id: Number(r.lastInsertRowid) } };
  }
  all() {
    const s = db.prepare(this.query);
    const results = s.all(...this.values);
    const meta = db.prepare('SELECT changes() AS changes, last_insert_rowid() AS last_row_id').get();
    return { success: true, results, meta };
  }
}
const binding = {
  prepare: sql => new Statement(sql),
  batch(queries) {
    db.exec('BEGIN');
    try {
      const result = queries.map(s => s.all());
      db.exec('COMMIT');
      return result;
    } catch (e) { db.exec('ROLLBACK'); throw e; }
  }
};
const game = createGameSite(handlePair, async key => {
  const file = join(root, 'dist', key);
  let details;
  try { details = await stat(file); } catch (e) { if (e.code === 'ENOENT') return null; throw e; }
  return details.isFile() && { length: details.size, read: () => readFile(file) };
});

const server = http.createServer(async (incoming, outgoing) => {
  try {
    const url = new URL(incoming.url, 'http://' + incoming.headers.host);
    const init = { method: incoming.method, headers: incoming.headers };
    if (!['GET', 'HEAD'].includes(init.method)) {
      init.duplex = 'half';
      init.body = Readable.toWeb(incoming);
    }
    const response = await game.fetch(new Request(url, init), { DB: binding });
    outgoing.writeHead(response.status, Object.fromEntries(response.headers));
    outgoing.end(response.body && Buffer.from(await response.arrayBuffer()));
  } catch (e) {
    console.error(e);
    if (!outgoing.headersSent) outgoing.writeHead(500);
    outgoing.end();
  }
});
const portArg = process.argv.indexOf('--port');
const port = Number(portArg < 0 ? process.env.PORT || 4173 : process.argv[portArg + 1]);
server.listen(port, '0.0.0.0', () => console.log('Roomie phone preview: http://localhost:' + server.address().port));
