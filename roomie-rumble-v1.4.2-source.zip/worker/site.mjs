// The production build and local preview use the same routing and response headers.
export const gameMime = {
  css: 'text/css; charset=utf-8', html: 'text/html; charset=utf-8',
  js: 'text/javascript; charset=utf-8', json: 'application/json; charset=utf-8',
  webp: 'image/webp', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg',
  svg: 'image/svg+xml', zip: 'application/zip'
};

export function gameAssetKey(pathname) {
  if (pathname === '/') return 'index.html';
  const key = pathname.slice(1);
  if (/^[\w-]+\.(?:html|css|js|json)$/.test(key)) return key;
  if (/^assets\/(?:[\w-]+\/)*[\w-]+\.(?:webp|png|jpe?g|svg)$/.test(key)) return key;
  return key === 'downloads/host.zip' ? key : null;
}

export function createGameSite(handlePair, getAsset) {
  return {
    async fetch(request, env) {
      const { pathname } = new URL(request.url);
      if (pathname.startsWith('/pair/')) return handlePair(request, env);
      if (!['GET', 'HEAD'].includes(request.method)) {
        return new Response(null, { status: 405, headers: { Allow: 'GET, HEAD' } });
      }
      const key = gameAssetKey(pathname);
      const item = key && await getAsset(key);
      if (!item) return new Response(null, { status: 404 });
      const headers = {
        'Content-Type': gameMime[key.slice(key.lastIndexOf('.') + 1)],
        'Content-Length': String(item.length),
        'Cache-Control': 'no-cache',
        'X-Content-Type-Options': 'nosniff',
        'Referrer-Policy': 'no-referrer'
      };
      if (item.etag) {
        headers.ETag = item.etag;
        if (request.headers.get('If-None-Match') === item.etag) {
          delete headers['Content-Length'];
          return new Response(null, { status: 304, headers });
        }
      }
      return new Response(request.method === 'HEAD' ? null : await item.read(), { headers });
    }
  };
}
