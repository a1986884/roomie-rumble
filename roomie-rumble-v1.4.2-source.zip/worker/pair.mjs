// The host phone owns simulation. D1 coordinates connection and, if needed, relays bounded input/frame mailboxes.
const LIFETIME = 2 * 60 * 60 * 1000;
const MAX_ROOMS = 512;
const MAX_MESSAGES_PER_SEAT = 512;
const MAX_ENVELOPE = 64 * 1024;
const utf8 = new TextDecoder('utf-8', { fatal: true });
const signalKinds = new Set(['offer', 'answer', 'ice', 'ready', 'restart']);
const noRoom = '房间已关闭、已过期或房号有误，请重新建房。';

function reply(data, status = 200) {
  return Response.json(data, { status, headers: { 'Cache-Control': 'no-store' } });
}

function reject(status, message) {
  throw Object.assign(new Error(message), { status });
}

async function readJSON(request, limit = MAX_ENVELOPE) {
  if (!/^application\/json\b/i.test(request.headers.get('Content-Type') || '')) reject(415, '需要 JSON 请求。');
  if (Number(request.headers.get('Content-Length')) > limit) reject(413, '连接信息太长，请重试。');
  const reader = request.body?.getReader();
  if (!reader) reject(400, '缺少连接信息。');
  const chunks = [];
  let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (size + value.byteLength > limit) {
        await reader.cancel();
        reject(413, '连接信息太长，请重试。');
      }
      chunks.push(value);
      size += value.byteLength;
    }
    let buffer = chunks[0] || new Uint8Array(0);
    if (chunks.length > 1) {
      buffer = new Uint8Array(size);
      let offset = 0;
      for (const chunk of chunks) { buffer.set(chunk, offset); offset += chunk.byteLength; }
    }
    const json = JSON.parse(utf8.decode(buffer));
    if (!json || typeof json !== 'object' || Array.isArray(json)) reject(400, '连接信息格式有误。');
    return json;
  } catch (error) {
    if (error.status) throw error;
    reject(400, '连接信息格式有误。');
  } finally {
    reader.releaseLock();
  }
}

function randomHex() {
  return hex(crypto.getRandomValues(new Uint8Array(24)));
}
function hex(bytes) {
  return Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
}
function isKey(value) { return typeof value === 'string' && /^[a-f0-9]{48}$/.test(value); }
async function keyDigest(token) {
  return hex(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(token))));
}
function freshKey(data) {
  if (data.requestKey === undefined) return randomHex();
  if (!isKey(data.requestKey)) reject(400, '建房凭据格式有误。');
  return data.requestKey;
}
function roomCode(data) {
  if (typeof data.room !== 'string' || !/^[0-9]{6}$/.test(data.room)) reject(400, '请输入六位房号。');
  return data.room;
}

async function create(db, data, now) {
  const token = freshKey(data), digest = await keyDigest(token);
  await db.prepare('DELETE FROM pair_rooms WHERE expires <= ?').bind(now).run();
  for (let attempt = 0; attempt < 8; attempt++) {
    const room = String(100000 + crypto.getRandomValues(new Uint32Array(1))[0] % 900000);
    const [, result] = await db.batch([
      db.prepare('INSERT OR IGNORE INTO pair_rooms (room,host_key,expires) SELECT ?,?,? WHERE (SELECT COUNT(*) FROM pair_rooms) < ?')
        .bind(room, digest, now + LIFETIME, MAX_ROOMS),
      db.prepare('SELECT room FROM pair_rooms WHERE host_key = ? AND expires > ?').bind(digest, now)
    ]);
    const saved = result.results[0];
    if (saved) return { room: saved.room, seat: 0, token };
    if (await db.prepare('SELECT COUNT(*) AS n FROM pair_rooms').first('n') >= MAX_ROOMS) reject(503, '房间已满，请稍后再试。');
  }
  reject(503, '暂时无法分配房号，请重试。');
}

async function join(db, data, now) {
  const room = roomCode(data), token = freshKey(data), digest = await keyDigest(token);
  const [, result] = await db.batch([
    db.prepare('UPDATE pair_rooms SET guest_key = ? WHERE room = ? AND expires > ? AND guest_key IS NULL AND host_key <> ?')
      .bind(digest, room, now, digest),
    db.prepare('SELECT guest_key FROM pair_rooms WHERE room = ? AND expires > ?').bind(room, now)
  ]);
  const saved = result.results[0];
  if (!saved) reject(404, noRoom);
  if (saved.guest_key !== digest) reject(409, '这个房间已满，请使用另一个房号。');
  return { room, seat: 1, token };
}

async function seatFor(db, data, now) {
  const room = roomCode(data);
  if (!isKey(data.token)) reject(403, '座位已失效，请重新加入。');
  const digest = await keyDigest(data.token);
  const row = await db.prepare('SELECT host_key, guest_key, EXISTS(SELECT 1 FROM pair_relay WHERE room = pair_rooms.room) AS relay FROM pair_rooms WHERE room = ? AND expires > ?').bind(room, now).first();
  if (!row) reject(404, noRoom);
  const seat = row.host_key === digest ? 0 : row.guest_key === digest ? 1 : -1;
  if (seat < 0) reject(403, '座位已失效，请重新加入。');
  return { room, seat, digest, guest: Boolean(row.guest_key), relay: Boolean(row.relay) };
}

async function send(db, seat, data, now) {
  const message = data.message;
  if (!message || !signalKinds.has(message.type)) reject(400, '不支持这个连接消息。');
  if (!/^[A-Za-z0-9_.:-]{1,128}$/.test(data.id || '') || typeof data.id !== 'string') reject(400, '缺少消息序号。');
  const encoded = JSON.stringify(message);
  if (encoded.length > 48 * 1024) reject(413, '连接消息太长，请重试。');
  // Recheck the seat in the insert: a leave followed by code reuse must never mix two rooms.
  const keyColumn = seat.seat === 0 ? 'host_key' : 'guest_key';
  const [insert, prior] = await db.batch([
    db.prepare('INSERT OR IGNORE INTO pair_messages (room,sender,client_id,message) SELECT ?,?,?,? FROM pair_rooms WHERE room = ? AND ' + keyColumn + ' = ? AND expires > ? AND (SELECT COUNT(*) FROM pair_messages WHERE room = ? AND sender = ?) < ?')
      .bind(seat.room, seat.seat, data.id, encoded, seat.room, seat.digest, now, seat.room, seat.seat, MAX_MESSAGES_PER_SEAT),
    db.prepare('SELECT client_id FROM pair_messages JOIN pair_rooms USING (room) WHERE room = ? AND ' + keyColumn + ' = ? AND sender = ? AND client_id = ?')
      .bind(seat.room, seat.digest, seat.seat, data.id)
  ]);
  if (!insert.meta.changes && !prior.results.length) reject(409, '房间已关闭或连接协商次数已用尽，请重新建房。');
  return { ok: true };
}

async function poll(db, seat, data, now) {
  const after = data.after ?? 0;
  if (!Number.isSafeInteger(after) || after < 0) reject(400, '读取位置无效。');
  const keyColumn = seat.seat === 0 ? 'host_key' : 'guest_key';
  const result = await db.prepare('SELECT id, message FROM pair_messages JOIN pair_rooms USING (room) WHERE room = ? AND ' + keyColumn + ' = ? AND expires > ? AND sender = ? AND id > ? ORDER BY id LIMIT 24')
    .bind(seat.room, seat.digest, now, 1 - seat.seat, after).all();
  return { closed: false, relay: seat.relay, connected: [true, seat.guest], messages: result.results.map(row => ({ id: row.id, message: JSON.parse(row.message) })) };
}

const relayLimits = { batch: 768 * 1024, frame: 16 * 1024, envelope: 848 * 1024, packets: 64, heartbeat: 7500 };
function isInstance(s) { return typeof s === 'string' && /^[A-Za-z0-9_-]{8,64}$/.test(s); }
function seq(n) { return Number.isSafeInteger(n) && n >= 0 && n <= 0x7fffffff; }
function isPacket(p) { return p !== null && typeof p === 'object' && !Array.isArray(p); }
function encodeLimited(p, limit) {
  const s = JSON.stringify(p);
  if (s.length > limit || new TextEncoder().encode(s).length > limit) reject(413, '同步数据太大，请减少头像大小后重试。');
  return s;
}

// The peer must acknowledge a reliable batch before the sender can replace it.
// A new frame may replace an older one immediately, subject to its reliable sequence barrier.
const updateMailbox = `
WITH incoming(room, seat, my_instance, remote_instance, ack, batch_seq, packets, frame_seq, frame_after, frame)
AS (VALUES (?,?,?,?,?,?,?,?,?,?)),
update_values AS (
  SELECT local.room, local.seat, inc.*, remote.instance AS destination,
    (local.peer <> remote.instance) AS reset,
    MIN(inc.ack, CASE WHEN remote.peer = local.instance THEN remote.batch_seq ELSE 0 END) AS safe_ack,
    (inc.batch_seq > 0 AND (
      (local.peer <> remote.instance AND inc.batch_seq = 1) OR
      (local.peer = remote.instance AND inc.batch_seq = local.batch_seq + 1 AND
        (local.batch_seq = 0 OR (remote.peer = local.instance AND remote.ack >= local.batch_seq)))
    )) AS accepts_batch,
    (inc.frame_seq > 0 AND (local.peer <> remote.instance OR inc.frame_seq > local.frame_seq)) AS accepts_frame,
    (remote.peer = local.instance AND remote.ack >= local.batch_seq) AS can_drop
  FROM incoming AS inc
  JOIN pair_relay AS local ON local.room = inc.room AND local.seat = inc.seat AND local.instance = inc.my_instance
  JOIN pair_relay AS remote ON remote.room = local.room AND remote.seat <> local.seat AND remote.instance = inc.remote_instance
)
UPDATE pair_relay AS stored SET
  peer = changes.destination,
  ack = CASE WHEN changes.reset THEN changes.safe_ack ELSE MAX(stored.ack, changes.safe_ack) END,
  batch_seq = CASE WHEN changes.accepts_batch THEN changes.batch_seq WHEN changes.reset THEN 0 ELSE stored.batch_seq END,
  packets = CASE WHEN changes.accepts_batch THEN changes.packets WHEN changes.reset OR changes.can_drop THEN NULL ELSE stored.packets END,
  frame_seq = CASE WHEN changes.accepts_frame THEN changes.frame_seq WHEN changes.reset THEN 0 ELSE stored.frame_seq END,
  frame_after = CASE WHEN changes.accepts_frame THEN changes.frame_after WHEN changes.reset THEN 0 ELSE stored.frame_after END,
  frame = CASE WHEN changes.accepts_frame THEN changes.frame WHEN changes.reset THEN NULL ELSE stored.frame END
FROM update_values AS changes
WHERE stored.room = changes.room AND stored.seat = changes.seat AND stored.instance = changes.my_instance`;

async function relayExchange(db, seat, data, now) {
  const { instance, peer = '', ack = 0, afterFrame = 0, batch, frame } = data;
  if (!isInstance(instance) || (peer !== '' && !isInstance(peer)) || !seq(ack) || !seq(afterFrame)) reject(400, '同步位置有误，请重新加入。');
  let packets = null, picture = null;
  if (batch !== undefined && batch !== null) {
    if (!seq(batch.seq) || batch.seq === 0 || !Array.isArray(batch.packets) || !batch.packets.length ||
        batch.packets.length > relayLimits.packets || !batch.packets.every(isPacket)) reject(400, '对战消息格式有误。');
    packets = encodeLimited(batch.packets, relayLimits.batch);
  }
  if (frame !== undefined && frame !== null) {
    if (!seq(frame.seq) || !frame.seq || !seq(frame.after) || !isPacket(frame.packet)) reject(400, '画面格式有误。');
    picture = encodeLimited(frame.packet, relayLimits.frame);
  }
  const keyColumn = seat.seat === 0 ? 'host_key' : 'guest_key';
  // A delayed request from the previous page cannot reclaim the newly active seat.
  const syncSeat = db.prepare(`
    INSERT INTO pair_relay (room,seat,instance,seen,away)
    SELECT ?,?,?,?,? FROM pair_rooms WHERE room = ? AND ` + keyColumn + ` = ? AND expires > ?
    ON CONFLICT (room,seat) DO UPDATE SET
      previous = CASE WHEN instance <> excluded.instance THEN instance ELSE previous END,
      peer = CASE WHEN instance <> excluded.instance THEN '' ELSE peer END,
      ack = CASE WHEN instance <> excluded.instance THEN 0 ELSE ack END,
      batch_seq = CASE WHEN instance <> excluded.instance THEN 0 ELSE batch_seq END,
      packets = CASE WHEN instance <> excluded.instance THEN NULL ELSE packets END,
      frame_seq = CASE WHEN instance <> excluded.instance THEN 0 ELSE frame_seq END,
      frame_after = CASE WHEN instance <> excluded.instance THEN 0 ELSE frame_after END,
      frame = CASE WHEN instance <> excluded.instance THEN NULL ELSE frame END,
      instance = excluded.instance, seen = MAX(seen, excluded.seen), away = excluded.away
    WHERE previous <> excluded.instance`).bind(seat.room, seat.seat, instance, now, Number(data.away === true), seat.room, seat.digest, now);
  const ops = [syncSeat];
  if (peer) ops.push(db.prepare(updateMailbox).bind(seat.room, seat.seat, instance, peer, ack, batch?.seq || 0, packets, frame?.seq || 0, frame?.after || 0, picture));
  ops.push(db.prepare('SELECT instance,peer,batch_seq FROM pair_relay WHERE room = ? AND seat = ?').bind(seat.room, seat.seat));
  // Filter old payloads in SQLite so acknowledged photos never travel on idle polls.
  ops.push(db.prepare(`
    SELECT instance,seen,away,peer,ack,batch_seq,frame_seq,frame_after,
      CASE WHEN instance = ? AND peer = ? AND batch_seq > ? THEN packets END AS packets,
      CASE WHEN instance = ? AND peer = ? AND frame_seq > ? THEN frame END AS frame
    FROM pair_relay WHERE room = ? AND seat = ?`).bind(peer, instance, ack, peer, instance, afterFrame, seat.room, 1 - seat.seat));
  const results = await db.batch(ops);
  const local = results[results.length - 2].results[0], remote = results.at(-1).results[0];
  if (!local) reject(404, noRoom);
  if (local.instance !== instance) reject(409, '另一页面已经接管了这个座位。');
  const sameTarget = Boolean(remote && local.peer === remote.instance);
  return {
    ok: true, instance, peer: remote?.instance || '', online: Boolean(remote && !remote.away && now - remote.seen < relayLimits.heartbeat),
    accepted: sameTarget ? local.batch_seq : 0, acked: remote?.peer === instance ? remote.ack : 0,
    batch: remote?.packets ? { seq: remote.batch_seq, packets: JSON.parse(remote.packets) } : null,
    frame: remote?.frame ? { seq: remote.frame_seq, after: remote.frame_after, packet: JSON.parse(remote.frame) } : null
  };
}

export async function handlePair(request, env) {
  const url = new URL(request.url);
  const action = url.pathname.replace(/^\/pair\//, '');
  if (action === 'info' && request.method === 'GET') {
    return env.DB ? reply({ available: true, version: 1, transport: 'webrtc' }) : reply({ available: false }, 503);
  }
  if (!['create', 'join', 'send', 'poll', 'relay', 'leave'].includes(action)) return reply({ error: '房间接口不存在。' }, 404);
  try {
    if (request.method !== 'POST') reject(405, '请通过游戏界面进入房间。');
    const origin = request.headers.get('Origin');
    if (origin && origin !== url.origin) reject(403, '请在游戏页面打开房间。');
    if (!env.DB) reject(503, '手机房间服务尚未开启。');
    const db = env.DB.withSession ? env.DB.withSession('first-primary') : env.DB;
    const data = await readJSON(request, action === 'relay' ? relayLimits.envelope : MAX_ENVELOPE), now = Date.now();
    if (action === 'create') return reply(await create(db, data, now));
    if (action === 'join') return reply(await join(db, data, now));
    const seat = await seatFor(db, data, now);
    if (action === 'relay') return reply(await relayExchange(db, seat, data, now));
    if (action === 'send') return reply(await send(db, seat, data, now));
    if (action === 'poll') return reply(await poll(db, seat, data, now));
    await db.prepare('DELETE FROM pair_rooms WHERE room = ? AND (host_key = ? OR guest_key = ?)').bind(seat.room, seat.digest, seat.digest).run();
    return reply({ ok: true });
  } catch (error) {
    return error.status ? reply({ error: error.message }, error.status) : reply({ error: '房间服务暂时无法响应，请稍后重试。' }, 503);
  }
}
